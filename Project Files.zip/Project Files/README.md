
# Student Details Website using Front End Developement

Its a simple student details project created using HTML, CSS, Javascript and Bootstrap.
It includes Login Page, Register Page, Students List Page, Details Of each Student Page, Edit Student Details Page,etc.

How to access:


The Files are created as per the pages inside the folders too.
To access the content in the flow, open the index.html file. It will take you to all the linked Html pages.


Login Page:

Includes Email Input, Password Input, Forgot Password, Register Here
Used Glassmorphism to make it look better.
It had validation too.

Registration page:

Includes input of Name, Mother Name, Email, Password, DOB, Country, City, State, Contact No, Gender
Submit and Reset Form button

Student List Page:

Includes Student Name, Email, Contact No, Course
More Details link and Edit Details Link is added to the section.

Student Details Page:

Includes student's photo,  nput of Name, Mother Name, Email, Password, DOB, Country, City, State, Contact No, Gender
It also includes back button to Student's List Page


Edit Details Page:

Includes the Student's Name, email, contact no, address to edit.



